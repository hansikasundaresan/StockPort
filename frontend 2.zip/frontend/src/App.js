import logo from './logo.svg';
import './App.css';
import React, { useState } from 'react';
import { useAuth0 } from '@auth0/auth0-react';
import LoginButton from './LoginButton';
import LogoutButton from './LogoutButton';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
//import { Button, Navbar, Nav, Container} from 'react-bootstrap';
import NaviBar from './components/navbar';
import StudentPage from './components/studentinfo';
import LoginPage from './components/LoginPage';
import HomePage from './components/HomePage';
import SearchPage from './components/SearchPage';
import Exchange from './components/Exchange';

function App() {
  const { user, isAuthenticated } = useAuth0();
  if(isAuthenticated){
    return (
      <div className="App">
        <div>
          <Router>
            <Switch>
              <Route exact path="/" component={HomePage} />
              <Route path="/student" component={StudentPage} />
              <Route path="/search" component={SearchPage} />
              <Route path="/stockexchange" component={Exchange} />
            </Switch>
          </Router>
      </div>
      </div>
    )
  }
  return (
    <div className="App">
    <div>
      <Router>
        <Switch>
          <Route exact path="/" component={LoginPage} />
        </Switch>
      </Router>
  </div>
  </div>
  );
}

export default App;
