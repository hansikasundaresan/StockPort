import React, {useState} from "react";
import { Formik, Field, Form } from "formik";
import NaviBar from './navbar';
import { useAuth0 } from '@auth0/auth0-react';


const Exchange = () => {
  const { user, isAuthenticated } = useAuth0();
  const [sub_val, Subtract] = useState([]);
  const [add_val, Add] = useState([]);

  return(
  <div>
      <NaviBar />
            <br></br>
            <br></br>
    <h1>Sell your stocks!</h1>
    <Formik
      initialValues={{
        stock_name: ""
      }}
      onSubmit={async (values2) => {
        await new Promise((r) => setTimeout(r, 500));
        fetch('http://127.0.0.1:5000/subtract-stock', {
                method: 'POST',
                cache: 'no-cache',
                headers: {
                    content_type: 'application/json',
                    },
                    body: JSON.stringify(user.email+" "+values2.stock_name),
                  }).then(response => response.json())
                .then(response => Subtract(response))
                .then(alert("The stock has been sold"))
                .catch(error => console.log(error))
        
      } 
    }
    >
      <Form>
        <label htmlFor="email">Stock Name &nbsp;&nbsp;&nbsp;</label>
        <Field
          id="stock_name"
          name="stock_name"
          placeholder="Amazon"
          type="string"
        />
        <button type="submit">Sell Stock</button>
      </Form>
    </Formik>
    <br></br>
    <br></br>
    <br></br>
    <h1>Buy new stocks!</h1>
    <Formik
      initialValues={{
        stock_name: ""
      }}
      onSubmit={async (values) => {
        await new Promise((r) => setTimeout(r, 500));
        fetch('http://127.0.0.1:5000/buy-stock', {
                method: 'POST',
                cache: 'no-cache',
                headers: {
                    content_type: 'application/json',
                    },
                    body: JSON.stringify(user.email+" "+values.stock_name),
                  }).then(response => response.json())
                .then(response => Add(response))
                .then(alert('The stock has been bought'))
                .catch(error => console.log(error))

      }}
    >
      <Form>
        <label htmlFor="email">Stock Name &nbsp;&nbsp;&nbsp;</label>
        <Field
          id="stock_name"
          name="stock_name"
          placeholder="Apple"
          type="string"
        />
        <button type="submit">Buy Stock </button>
      </Form>
    </Formik>
  </div>
  )};
export default Exchange;
