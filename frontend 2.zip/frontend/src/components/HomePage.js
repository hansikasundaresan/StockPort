import React, {useState,useEffect} from 'react';
import NaviBar from './navbar';
import { useAuth0 } from '@auth0/auth0-react';
import NewsItem from './Item';

const HomePage = () => {
    const {user, isAuthenticated} = useAuth0();
    const [userinfo,setInfo] = useState([]);
    const [newsDate, setNews] = useState([]);

    useEffect(()=>{
        fetch('http://127.0.0.1:5000/user-stock-info', {
            method: 'POST',
            cache: 'no-cache',
            headers: {
                content_type: 'application/json',
              },
              body: JSON.stringify(user.email),
        }).then(response => response.json())
          .then(response => setInfo(response))
          .catch(error => console.log(error))
        fetch('http://127.0.0.1:5000/general-news', {
        method: 'GET',
        cache: 'no-cache',
        headers: {
            content_type: 'application/json',
            },
    }).then(response => response.json())
        .then(response => setNews(response))
        .catch(error => console.log(error))
    },[])

    return (
        <div>
            <NaviBar />
            <br></br>
            <span className="announcement">Your Current Stocks <br></br><br></br><br></br></span>
            <div className='lightgray-background'>
            {
            Object.keys(userinfo).map((key, index) => ( 
          <p className='text-decoration-forlink' key={index}> {key}: ${userinfo[key]} </p> 
        ))}</div>
        <br></br><br></br>
        <br></br>
            <span className="announcement">Current News <br></br><br></br></span>

        {
           newsDate.map((news) => (
            <NewsItem key={news.id} item={news}/>
            ))
        }
        
        </div> 
    );
};

export default HomePage;