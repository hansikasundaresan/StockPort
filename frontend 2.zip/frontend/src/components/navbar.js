import React from 'react';
import { Navbar, Nav, Container, NavDropdown } from 'react-bootstrap';
import { LinkContainer } from 'react-router-bootstrap';
import { useAuth0 } from '@auth0/auth0-react';
import LogoutButton from '../LogoutButton';
import 'bootstrap/dist/css/bootstrap.css';
import LoginButton from '../LoginButton';
import image from './img.png'

const NaviBar = () => {
    const { user, isAuthenticated } = useAuth0();
    if(isAuthenticated){
        return (
        <Navbar bg="primary" variant="dark">
        <Navbar.Brand href="#home" className='headertxtpink'>Stock Port</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
      <Navbar.Collapse id="basic-navbar-nav">
        <Nav className="mr-auto">
          <LinkContainer to="/">
            <Nav.Link >
              <span className='headertxtwhite'>Home</span>
            </Nav.Link>
          </LinkContainer>
          <LinkContainer to="/student">
            <Nav.Link >
              <span className='headertxtwhite'>Student</span>
            </Nav.Link>
          </LinkContainer>
          <LinkContainer to="/search">
            <Nav.Link >
              <span className='headertxtwhite'>Search</span>
            </Nav.Link>
          </LinkContainer>
          <LinkContainer to="/stockexchange">
            <Nav.Link >
              <span className='headertxtwhite'>Exchange</span>
            </Nav.Link>
          </LinkContainer>
        </Nav>
      </Navbar.Collapse>
        <LogoutButton />
        </Navbar>
        ); 
    }
    else
    return (
        <Navbar bg="primary" variant="dark">
  <Container>
    <Navbar.Brand href="#home" className='headertxtpink'>Stock Port</Navbar.Brand>
  </Container>
  <LoginButton />
</Navbar>
    );
};

export default NaviBar;