import React, {Component} from 'react';

class NewsItem extends Component {
    render() {
        return (
            <div>
                <a href={this.props.item.url} className='info-text-impt'> {this.props.item.headline}</a>
                <img src={this.props.item.image}/>
                <br></br>
                <br></br>
                <br></br>
            </div>
        );
    }
}

export default NewsItem;