import React from 'react';
import NaviBar from './navbar';

const StudentPage = () => {
    return (
        <div>
            <NaviBar />
            <br></br>
          <br></br>
          <p className='single-colmtxt-center-yellow'>Hi!</p> <p className='info-txt2'>Welcome to Stock Port, we are glad you are here to learn more about the stock market!
            Make sure to read over the main tips before getting started with your stock journey!!</p><br></br><br></br>
            <ul>
              <li>Buy the right investment</li>
              <li>Avoid individual stocks if you’re a beginner</li>
              <li>Create a diversified portfolio</li>       
              <li>Be prepared for a downturn</li>
              <li>Stay committed to your long-term portfolio</li>
              <li>Start now!!!</li>

            </ul>
           </div>
    )
};

export default StudentPage;
