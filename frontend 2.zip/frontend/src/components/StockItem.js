import React, {Component} from 'react';
import Chart from './Chart';
class StockItem extends Component {
    render() {
        return (
            <div>
            <div class="row">
            <div class="column"><p>Stock: {this.props.item.name}</p></div>
            <div class="column"><p>Current Proposal: {this.props.item.recommendation}</p></div>
            </div>
            <div class="row">

            <div class="column"><p>Stock Price: {this.props.item.price}</p></div>
            <div class="column"><p> Sentiment: {this.props.item.sentiment}</p></div>
            </div>

            <div><p className='info-text-impt'>Sell?: {this.props.item.sell_recommendation}</p></div>
             <br></br>
            <div>
                <Chart stock = {this.props.item.name}/>,
            </div>
        </div>
        );
    }
}

export default StockItem;