import React, { useState } from 'react';
import NaviBar from './navbar';
import { Formik, Field, Form } from 'formik';
import StockItem from './StockItem';
import { is } from 'core-js/core/object';
import Chart from './Chart';

const SearchPage = () => {
    const [searchStock, stockSearch] = useState([]);
    const [fetched,isFetch] = useState(false);
    if(fetched){
        return (
          <div>
            <NaviBar />
            <br></br>
            <br></br>
            {
                <StockItem key={searchStock.symbol} item={searchStock}/>
            }
        </div>
        )
    }
    return(
    <div>
      <Formik
        initialValues={{
          stock_name: '',
        }}
        onSubmit={async (values) => {
          await new Promise((r) => setTimeout(r, 500));
            fetch('http://127.0.0.1:5000/stock-recs', {
                method: 'POST',
                cache: 'no-cache',
                headers: {
                    content_type: 'application/json',
                    },
                    body: JSON.stringify(values.stock_name),
            }).then(response => response.json())
                .then(response => stockSearch(response))
                .then(isFetch(true))
                .catch(error => console.log(error))
        }}
      >
        <Form>
        <NaviBar />
          <br></br>
          <br></br>
      <h1>Search Up a Company!</h1>
          <label htmlFor="email">Stock Name  &nbsp;&nbsp;&nbsp;
   </label>
          <Field
            id="stock_name"
            name="stock_name"
            placeholder="Amazon"
            type="string"
          />
          <button type="submit">Submit</button>
        </Form>
      </Formik>
    </div>);
};
  
export default SearchPage;
