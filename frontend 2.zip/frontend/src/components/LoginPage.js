import React from 'react';
import NaviBar from './navbar';
import '../css/colors.css'
import image from './image.png'

const LoginPage = () => {
    return (
        <div> 
            <NaviBar />
            <div className='container'>
            <img src={image} alt="snow" style={{width:'100%'}}/>
             <span className="center">Welcome to Stock Port  <br></br>
             Login to view you stocks
             </span></div></div>
    );
};

export default LoginPage;